# HyperDroid Plus 0.6

Launcher/desktop para Android feito em Java + WebView, com interface desktop inspirada no Windows 11.

## Recursos
- Desktop com barra de tarefas, relógio, menu Iniciar e pesquisa de aplicativos.
- Janelas internas HTML arrastáveis, minimizáveis, maximizáveis e fecháveis.
- Descoberta de atividades Android lançáveis e abertura dos aplicativos pelo sistema.
- Seletor de documentos do Android para arquivos, imagens, GIFs, vídeos e áudio, sem solicitar acesso amplo ao armazenamento.
- Wallpapers GIF/vídeo dentro do desktop, com tentativa de restauração ao reabrir o launcher.
- Player de áudio, visualização de imagem, navegador externo e calculadora com parser aritmético próprio.
- Bloco de notas com salvamento local no WebView.
- Controle do volume de mídia e atalhos para as configurações de Wi-Fi/Bluetooth do Android.
- GitHub Actions para compilar automaticamente um APK de debug.

## Requisitos de compilação
- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## Gerar o APK pelo GitHub
1. Envie o **conteúdo desta pasta** para a raiz do repositório `HyperDroidPlus` (incluindo `.github`, `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, `.gitignore` e `README.md`). Não envie apenas o arquivo ZIP esperando que o GitHub o extraia.
2. Faça o commit na branch `main` ou `master`.
3. Abra a aba **Actions** do repositório.
4. Selecione **Build HyperDroid Plus APK** e abra a execução mais recente.
5. Quando terminar com sucesso, baixe o artefato **HyperDroidPlus-v0.6-debug**.
6. Extraia o artefato baixado e instale `app-debug.apk` no Android.

Também é possível iniciar a compilação manualmente em **Actions > Build HyperDroid Plus APK > Run workflow**.

## Limitações importantes
- Aplicativos Android instalados abrem como atividades normais do sistema. Eles não são incorporados às janelas HTML do HyperDroid Plus.
- O wallpaper animado aparece dentro do desktop enquanto o launcher está aberto; ele não substitui o papel de parede do sistema Android.
- A disponibilidade da lista de aplicativos depende das regras de visibilidade de pacotes do Android e da ROM do aparelho.
- O seletor concede acesso apenas aos arquivos escolhidos pelo usuário. A restauração de mídia depende de o Android manter a permissão persistente para o URI selecionado.
- O APK gerado pelo workflow é de **debug**, para testes. Não é uma versão assinada para publicação na Play Store.

## Estado de validação
A estrutura do projeto, o XML do manifesto e a sintaxe JavaScript podem ser verificados separadamente. A compilação Android e o funcionamento no aparelho precisam ser confirmados pela execução do GitHub Actions e por teste no dispositivo; não declare o APK aprovado antes dessas etapas.
