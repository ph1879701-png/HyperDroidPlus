package com.hyperdroid.plus;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.media.AudioManager;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 4101;
    private static final int PICK_FILE = 4102;
    private WebView web;
    private String pendingPicker = "media";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        web = new WebView(this);
        web.setBackgroundColor(0xff0b1425);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeBridge(), "HyperNative");
        setContentView(web);
        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface public String getApps() {
            JSONArray out = new JSONArray();
            try {
                Intent intent = new Intent(Intent.ACTION_MAIN, null);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                PackageManager pm = getPackageManager();
                List<ResolveInfo> items = pm.queryIntentActivities(intent, 0);
                Collections.sort(items, new Comparator<ResolveInfo>() {
                    public int compare(ResolveInfo a, ResolveInfo b) {
                        return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
                    }
                });
                for (ResolveInfo ri : items) {
                    JSONObject o = new JSONObject();
                    o.put("name", ri.loadLabel(pm).toString());
                    o.put("packageName", ri.activityInfo.packageName);
                    o.put("icon", "📱");
                    out.put(o);
                }
            } catch (Exception ignored) {}
            return out.toString();
        }
        @JavascriptInterface public void launchApp(String packageName) {
            runOnUiThread(() -> {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
                    if (launch != null) startActivity(launch);
                    else Toast.makeText(MainActivity.this, "Não foi possível abrir esse aplicativo.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Falha ao abrir o aplicativo.", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void pickMedia(String type) {
            runOnUiThread(() -> {
                pendingPicker = "media";
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                if ("video".equals(type)) i.setType("video/*");
                else if ("gif".equals(type)) i.setType("image/gif");
                else if ("image".equals(type)) i.setType("image/*");
                else if ("audio".equals(type)) i.setType("audio/*");
                startActivityForResult(i, PICK_MEDIA);
            });
        }
        @JavascriptInterface public void pickFile() {
            runOnUiThread(() -> {
                pendingPicker = "file";
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, PICK_FILE);
            });
        }
        @JavascriptInterface public void openSettings(String page) {
            runOnUiThread(() -> {
                try {
                    Intent i;
                    if ("wifi".equals(page)) i = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    else if ("bluetooth".equals(page)) i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                    else i = new Intent(Settings.ACTION_SETTINGS);
                    startActivity(i);
                } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            });
        }
        @JavascriptInterface public void setVolume(int value) {
            runOnUiThread(() -> {
                AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(max, Math.round(max * value / 100f))), 0);
            });
        }
        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url);
                    if (!"https".equals(uri.getScheme()) && !"http".equals(uri.getScheme())) return;
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == PICK_MEDIA || requestCode == PICK_FILE) && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) {}
            String mime = getContentResolver().getType(uri);
            String js = "window.onNativeFileSelected && window.onNativeFileSelected(" + JSONObject.quote(uri.toString()) + "," + JSONObject.quote(mime == null ? "" : mime) + "," + JSONObject.quote(pendingPicker) + ");";
            if (web != null) web.post(() -> web.evaluateJavascript(js, null));
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) { if (web != null) web.saveState(out); super.onSaveInstanceState(out); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
